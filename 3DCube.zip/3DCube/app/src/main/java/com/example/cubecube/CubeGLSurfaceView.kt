
package com.example.cubecube

import android.content.Context
import android.opengl.GLSurfaceView
import android.view.MotionEvent
import kotlin.math.abs

class CubeGLSurfaceView(context: Context) : GLSurfaceView(context) {

    private val renderer: CubeRenderer

    private var downX = 0f
    private var downY = 0f

    init {
        setEGLContextClientVersion(2)

        renderer = CubeRenderer(context)

        setRenderer(renderer)

        renderMode = RENDERMODE_CONTINUOUSLY
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {

        when (event.actionMasked) {

            MotionEvent.ACTION_DOWN -> {
                downX = event.x
                downY = event.y
                return true
            }

            MotionEvent.ACTION_UP -> {

                val dx = event.x - downX
                val dy = event.y - downY

                // Horizontal swipe
                if (abs(dx) > 30f && abs(dx) > abs(dy)) {

                    if (dx > 0) {
                        renderer.rotateRight()
                    } else {
                        renderer.rotateLeft()
                    }

                    return true
                }

                // Vertical swipe
                if (abs(dy) > 30f && abs(dy) > abs(dx)) {

                    if (dy > 0) {
                        renderer.rotateDown()
                    } else {
                        renderer.rotateUp()
                    }

                    return true
                }

                // Tap
                if (abs(dx) < 30f && abs(dy) < 30f) {

                    val face = renderer.getFrontFace()
                    val item = renderer.getItem(face)

                    val intent = android.content.Intent(
                        context,
                        ContentActivity::class.java
                    )

                    intent.putExtra("name", item.name)
                    intent.putExtra("content", item.content)

                    context.startActivity(intent)
                }

                return true
            }
        }

        return true
    }
}