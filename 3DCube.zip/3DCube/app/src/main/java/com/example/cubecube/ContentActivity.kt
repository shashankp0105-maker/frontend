package com.example.cubecube

import android.graphics.Color
import android.os.Bundle
import android.view.Gravity
import android.widget.LinearLayout
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class ContentActivity : AppCompatActivity() {
    private lateinit var preferences: android.content.SharedPreferences

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        preferences = getSharedPreferences(
            "cube_data",
            MODE_PRIVATE
        )

        val name =
            intent.getStringExtra("name") ?: "Unknown"

        val originalContent =
            intent.getStringExtra("content") ?: "No content"


        val content =
            preferences.getString(
                name,
                originalContent
            ) ?: originalContent

        val root = LinearLayout(this)

        root.orientation = LinearLayout.VERTICAL

        root.gravity = Gravity.CENTER

        root.setPadding(
            40,
            40,
            40,
            40
        )

        root.setBackgroundColor(
            Color.rgb(15, 15, 20)
        )

        val title = TextView(this)

        title.text = name
        title.textSize = 32f
        title.setTextColor(Color.WHITE)
        title.gravity = Gravity.CENTER

        val body = TextView(this)

        body.text = content
        body.textSize = 20f
        body.setTextColor(Color.LTGRAY)
        body.gravity = Gravity.CENTER

        body.setPadding(
            20,
            40,
            20,
            40
        )
        root.addView(title)
        root.addView(body)

        val editButton = android.widget.Button(this)

        editButton.text = "Edit"
        editButton.setOnClickListener {

            val editText = android.widget.EditText(this)

            editText.setText(content)

            root.addView(editText)
            val saveButton = android.widget.Button(this)

            saveButton.text = "Save"

            saveButton.setOnClickListener {

                val newContent = editText.text.toString()

                preferences.edit()
                    .putString(name, newContent)
                    .apply()

                body.text = newContent

                root.removeView(editText)
                root.removeView(saveButton)
            }

            root.addView(saveButton)
        }

        root.addView(editButton)

        setContentView(root)

    }
}
