package com.example.cubecube

data class CubeItem(
    val id: String,
    val name: String,
    val iconRes: Int,
    val content: String
)