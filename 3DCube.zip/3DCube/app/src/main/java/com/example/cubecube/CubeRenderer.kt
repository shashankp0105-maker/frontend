package com.example.cubecube

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.drawable.Drawable
import android.opengl.GLES20
import android.opengl.GLUtils
import android.opengl.GLSurfaceView
import android.opengl.Matrix
import kotlin.math.round
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.nio.FloatBuffer
import android.graphics.LinearGradient
import android.graphics.Shader

class CubeRenderer(
    private val context: Context
) : GLSurfaceView.Renderer {

    private var rotationX = 0f
    private var rotationY = 0f
    private val projectionMatrix = FloatArray(16)
    private val viewMatrix = FloatArray(16)
    private val modelMatrix = FloatArray(16)
    private val mvpMatrix = FloatArray(16)

    private lateinit var vertexBuffer: FloatBuffer
    private lateinit var textureBuffer: FloatBuffer

     private var program = 0
     private var textureProgram=0
     private var homeTexture=0
     private var messagesTexture = 0
     private var reelsTexture = 0
     private var searchTexture = 0
     private var profileTexture = 0
     private var settingsTexture = 0
    private val items = listOf(
        CubeItem(
            "home",
            "Home",
            android.R.drawable.ic_menu_view,
            "This is the Home page."
        ),
        CubeItem(
            "messages",
            "Messages",
            android.R.drawable.ic_dialog_email,
            "This is the Messages page."
        ),
        CubeItem(
            "reels",
            "Reels",
            android.R.drawable.ic_media_play,
            "This is the Reels page."
        ),
        CubeItem(
            "search",
            "Search",
            android.R.drawable.ic_menu_search,
            "This is the Search page."
        ),
        CubeItem(
            "profile",
            "Profile",
            android.R.drawable.ic_menu_myplaces,
            "This is the Profile page."
        ),
        CubeItem(
            "settings",
            "Settings",
            android.R.drawable.ic_menu_preferences,
            "This is the Settings page."
        )
    )
    private val textureCoordinates = floatArrayOf(
        0f, 1f,
        1f, 1f,
        1f, 0f,

        0f, 1f,
        1f, 0f,
        0f, 0f
    )
    private val vertices = floatArrayOf(

        // Front
        -1f, -1f,  1f,
        1f, -1f,  1f,
        1f,  1f,  1f,

        -1f, -1f,  1f,
        1f,  1f,  1f,
        -1f,  1f,  1f,

        // Back
        1f, -1f, -1f,
        -1f, -1f, -1f,
        -1f,  1f, -1f,

        1f, -1f, -1f,
        -1f,  1f, -1f,
        1f,  1f, -1f,

        // Left
        -1f, -1f, -1f,
        -1f, -1f,  1f,
        -1f,  1f,  1f,

        -1f, -1f, -1f,
        -1f,  1f,  1f,
        -1f,  1f, -1f,

        // Right
        1f, -1f,  1f,
        1f, -1f, -1f,
        1f,  1f, -1f,

        1f, -1f,  1f,
        1f,  1f, -1f,
        1f,  1f,  1f,

        // Top
        -1f,  1f,  1f,
        1f,  1f,  1f,
        1f,  1f, -1f,

        -1f,  1f,  1f,
        1f,  1f, -1f,
        -1f,  1f, -1f,

        // Bottom
        -1f, -1f, -1f,
        1f, -1f, -1f,
        1f, -1f,  1f,

        -1f, -1f, -1f,
        1f, -1f,  1f,
        -1f, -1f,  1f
    )

    private val colors = floatArrayOf(
        // Front
        0.15f, 0.45f, 0.95f, 1f,

        // Back
        0.95f, 0.25f, 0.25f, 1f,

        // Left
        0.25f, 0.75f, 0.35f, 1f,

        // Right
        0.95f, 0.65f, 0.15f, 1f,

        // Top
        0.65f, 0.30f, 0.90f, 1f,

        // Bottom
        0.15f, 0.80f, 0.80f, 1f
    )

    init {
        val byteBuffer =
            ByteBuffer
                .allocateDirect(vertices.size * 4)
                .order(ByteOrder.nativeOrder())

        vertexBuffer = byteBuffer.asFloatBuffer()

        vertexBuffer.put(vertices)
        vertexBuffer.position(0)
        val textureByteBuffer =
            ByteBuffer
                .allocateDirect(textureCoordinates.size * 4)
                .order(ByteOrder.nativeOrder())

        textureBuffer =
            textureByteBuffer.asFloatBuffer()

        textureBuffer.put(textureCoordinates)
        textureBuffer.position(0)
    }

    override fun onSurfaceCreated(
        gl: javax.microedition.khronos.opengles.GL10?,
        config: javax.microedition.khronos.egl.EGLConfig?
    ) {
        GLES20.glClearColor(
            0.03f,
            0.03f,
            0.05f,
            1f
        )

        GLES20.glEnable(GLES20.GL_DEPTH_TEST)

        val vertexShaderCode = """
            attribute vec4 vPosition;
            uniform mat4 uMVPMatrix;

            void main() {
                gl_Position = uMVPMatrix * vPosition;
            }
        """.trimIndent()

        val fragmentShaderCode = """
            precision mediump float;

            uniform vec4 uColor;

            void main() {
                gl_FragColor = uColor;
            }
        """.trimIndent()

        val vertexShader =
            loadShader(
                GLES20.GL_VERTEX_SHADER,
                vertexShaderCode
            )

        val fragmentShader =
            loadShader(
                GLES20.GL_FRAGMENT_SHADER,
                fragmentShaderCode
            )

        program =
            GLES20.glCreateProgram()

        GLES20.glAttachShader(
            program,
            vertexShader
        )

        GLES20.glAttachShader(
            program,
            fragmentShader
        )

        GLES20.glLinkProgram(program)
        homeTexture = createFaceTexture(
            "Home",
            android.R.drawable.ic_menu_view,
            android.graphics.Color.rgb(0, 80, 255),
            android.graphics.Color.rgb(0, 220, 255)
        )
        messagesTexture = createFaceTexture(
            "Messages",
            android.R.drawable.ic_dialog_email,
            android.graphics.Color.rgb(0, 200, 180),
            android.graphics.Color.rgb(0, 100, 255)
        )

        reelsTexture = createFaceTexture(
            "Reels",
            android.R.drawable.ic_media_play,
            android.graphics.Color.rgb(255, 0, 100),
            android.graphics.Color.rgb(120, 0, 255)
        )
        searchTexture = createFaceTexture(
            "Search",
            android.R.drawable.ic_menu_search,
            android.graphics.Color.rgb(0, 200, 80),
            android.graphics.Color.rgb(0, 120, 255)
        )

        profileTexture = createFaceTexture(
            "Profile",
            android.R.drawable.ic_menu_myplaces,
            android.graphics.Color.rgb(255, 140, 0),
            android.graphics.Color.rgb(255, 40, 80)
        )

        settingsTexture = createFaceTexture(
            "Settings",
            android.R.drawable.ic_menu_preferences,
            android.graphics.Color.rgb(120, 0, 255),
            android.graphics.Color.rgb(255, 0, 180)
        )
        val textureVertexShaderCode = """
    attribute vec4 vPosition;
    attribute vec2 aTexCoord;

    uniform mat4 uMVPMatrix;

    varying vec2 vTexCoord;

    void main() {
        gl_Position = uMVPMatrix * vPosition;
        vTexCoord = aTexCoord;
    }
""".trimIndent()

        val textureFragmentShaderCode = """
    precision mediump float;

    uniform sampler2D uTexture;

    varying vec2 vTexCoord;

    void main() {
        gl_FragColor = texture2D(uTexture, vTexCoord);
    }
""".trimIndent()

        val textureVertexShader =
            loadShader(
                GLES20.GL_VERTEX_SHADER,
                textureVertexShaderCode
            )

        val textureFragmentShader =
            loadShader(
                GLES20.GL_FRAGMENT_SHADER,
                textureFragmentShaderCode
            )

        textureProgram =
            GLES20.glCreateProgram()

        GLES20.glAttachShader(
            textureProgram,
            textureVertexShader
        )

        GLES20.glAttachShader(
            textureProgram,
            textureFragmentShader
        )

        GLES20.glLinkProgram(textureProgram)

    }

    override fun onSurfaceChanged(
        gl: javax.microedition.khronos.opengles.GL10?,
        width: Int,
        height: Int
    ) {
        GLES20.glViewport(
            0,
            0,
            width,
            height
        )

        val ratio =
            width.toFloat() / height.toFloat()

        Matrix.frustumM(
            projectionMatrix,
            0,
            -ratio,
            ratio,
            -1f,
            1f,
            2f,
            10f
        )
    }

    override fun onDrawFrame(
        gl: javax.microedition.khronos.opengles.GL10?
    ) {
        rotationY += 0.15f
        GLES20.glClear(
            GLES20.GL_COLOR_BUFFER_BIT or
                    GLES20.GL_DEPTH_BUFFER_BIT
        )

        Matrix.setLookAtM(
            viewMatrix,
            0,
            0f,
            0f,
            5f,
            0f,
            0f,
            0f,
            0f,
            1f,
            0f
        )

        Matrix.setIdentityM(
            modelMatrix,
            0
        )

        Matrix.rotateM(
            modelMatrix,
            0,
            rotationX,
            1f,
            0f,
            0f
        )

        Matrix.rotateM(
            modelMatrix,
            0,
            rotationY,
            0f,
            1f,
            0f
        )

        val tempMatrix =
            FloatArray(16)

        Matrix.multiplyMM(
            tempMatrix,
            0,
            viewMatrix,
            0,
            modelMatrix,
            0
        )

        Matrix.multiplyMM(
            mvpMatrix,
            0,
            projectionMatrix,
            0,
            tempMatrix,
            0
        )

        GLES20.glUseProgram(program)

        val positionHandle =
            GLES20.glGetAttribLocation(
                program,
                "vPosition"
            )

        val matrixHandle =
            GLES20.glGetUniformLocation(
                program,
                "uMVPMatrix"
            )

        val colorHandle =
            GLES20.glGetUniformLocation(
                program,
                "uColor"
            )

        vertexBuffer.position(0)

        GLES20.glEnableVertexAttribArray(
            positionHandle
        )

        GLES20.glVertexAttribPointer(
            positionHandle,
            3,
            GLES20.GL_FLOAT,
            false,
            3 * 4,
            vertexBuffer
        )

        GLES20.glUniformMatrix4fv(
            matrixHandle,
            1,
            false,
            mvpMatrix,
            0
        )

        for (face in 0 until 6) {

            val colorIndex = face * 4

            GLES20.glUniform4f(
                colorHandle,
                colors[colorIndex],
                colors[colorIndex + 1],
                colors[colorIndex + 2],
                colors[colorIndex + 3]
            )

            GLES20.glDrawArrays(
                GLES20.GL_TRIANGLES,
                face * 6,
                6
            )
        }

        GLES20.glDisableVertexAttribArray(
            positionHandle
        )
        GLES20.glUseProgram(textureProgram)

        val texturePositionHandle =
            GLES20.glGetAttribLocation(
                textureProgram,
                "vPosition"
            )

        val textureCoordHandle =
            GLES20.glGetAttribLocation(
                textureProgram,
                "aTexCoord"
            )

        val textureMatrixHandle =
            GLES20.glGetUniformLocation(
                textureProgram,
                "uMVPMatrix"
            )

        val textureSamplerHandle =
            GLES20.glGetUniformLocation(
                textureProgram,
                "uTexture"
            )

        vertexBuffer.position(0)

        GLES20.glEnableVertexAttribArray(
            texturePositionHandle
        )

        GLES20.glVertexAttribPointer(
            texturePositionHandle,
            3,
            GLES20.GL_FLOAT,
            false,
            3 * 4,
            vertexBuffer
        )

        textureBuffer.position(0)

        GLES20.glEnableVertexAttribArray(
            textureCoordHandle
        )

        GLES20.glVertexAttribPointer(
            textureCoordHandle,
            2,
            GLES20.GL_FLOAT,
            false,
            2 * 4,
            textureBuffer
        )

        GLES20.glUniformMatrix4fv(
            textureMatrixHandle,
            1,
            false,
            mvpMatrix,
            0
        )

        GLES20.glActiveTexture(
            GLES20.GL_TEXTURE0
        )

        GLES20.glDepthFunc(GLES20.GL_LEQUAL)
        val textures = intArrayOf(
            homeTexture,
            messagesTexture,
            reelsTexture,
            searchTexture,
            profileTexture,
            settingsTexture
        )

        for (face in 0 until 6) {

            vertexBuffer.position(face * 6 * 3)

            GLES20.glVertexAttribPointer(
                texturePositionHandle,
                3,
                GLES20.GL_FLOAT,
                false,
                3 * 4,
                vertexBuffer
            )

            textureBuffer.position(0)

            GLES20.glVertexAttribPointer(
                textureCoordHandle,
                2,
                GLES20.GL_FLOAT,
                false,
                2 * 4,
                textureBuffer
            )

            GLES20.glBindTexture(
                GLES20.GL_TEXTURE_2D,
                textures[face]
            )

            GLES20.glDrawArrays(
                GLES20.GL_TRIANGLES,
                0,
                6
            )
        }

        GLES20.glUniform1i(
            textureSamplerHandle,
            0
        )

        GLES20.glDrawArrays(
            GLES20.GL_TRIANGLES,
            0,
            6
        )

        GLES20.glBindTexture(
            GLES20.GL_TEXTURE_2D,
            0
        )

        GLES20.glDisableVertexAttribArray(
            texturePositionHandle
        )

        GLES20.glDisableVertexAttribArray(
            textureCoordHandle
        )
        GLES20.glEnable(GLES20.GL_DEPTH_TEST)
    }

    private fun loadShader(
        type: Int,
        code: String
    ): Int {

        val shader =
            GLES20.glCreateShader(type)

        GLES20.glShaderSource(
            shader,
            code
        )

        GLES20.glCompileShader(shader)

        return shader
    }

    fun rotateLeft() {
        rotationY -= 90f
    }

    fun rotateRight() {
        rotationY += 90f
    }

    fun rotateUp() {
        rotationX -= 90f
    }

    fun rotateDown() {
        rotationX += 90f
    }
    fun getFrontFace(): Int {

        val rotationMatrix = FloatArray(16)

        Matrix.setIdentityM(
            rotationMatrix,
            0
        )

        Matrix.rotateM(
            rotationMatrix,
            0,
            rotationX,
            1f,
            0f,
            0f
        )

        Matrix.rotateM(
            rotationMatrix,
            0,
            rotationY,
            0f,
            1f,
            0f
        )

        val normals = arrayOf(
            floatArrayOf(0f, 0f, 1f, 0f),   // Front
            floatArrayOf(0f, 0f, -1f, 0f),  // Back
            floatArrayOf(-1f, 0f, 0f, 0f),  // Left
            floatArrayOf(1f, 0f, 0f, 0f),   // Right
            floatArrayOf(0f, 1f, 0f, 0f),   // Top
            floatArrayOf(0f, -1f, 0f, 0f)   // Bottom
        )

        var bestFace = 0
        var bestZ = -Float.MAX_VALUE

        val transformed = FloatArray(4)

        for (i in normals.indices) {

            Matrix.multiplyMV(
                transformed,
                0,
                rotationMatrix,
                0,
                normals[i],
                0
            )

            if (transformed[2] > bestZ) {
                bestZ = transformed[2]
                bestFace = i
            }
        }

        return bestFace
    }


    fun getItem(index: Int): CubeItem {
        return items[index]
    }
    private fun createFaceTexture(
        title: String,
        iconRes: Int,
        color1: Int,
        color2: Int
    ): Int {
        val bitmap =
            Bitmap.createBitmap(
                256,
                256,
                Bitmap.Config.ARGB_8888
            )

        val canvas = Canvas(bitmap)
        val paint = Paint(Paint.ANTI_ALIAS_FLAG)
        val gradient = LinearGradient(
            0f,
            0f,
            256f,
            256f,
            color1,
            color2,
            Shader.TileMode.CLAMP
        )

        paint.shader = gradient

        canvas.drawRect(
            0f,
            0f,
            256f,
            256f,
            paint
        )

        paint.shader = null

        paint.color =
            android.graphics.Color.BLACK

        paint.textSize = 40f

        paint.textAlign =
            Paint.Align.CENTER

        canvas.drawText(
            title,
            128f,
            220f,
            paint
        )

        val drawable: Drawable? =
            context.getDrawable(
                iconRes
            )

        drawable?.setBounds(
            78,
            30,
            178,
            130
        )

        drawable?.draw(canvas)

        val textureIds =
            IntArray(1)

        GLES20.glGenTextures(
            1,
            textureIds,
            0
        )

        val textureId =
            textureIds[0]

        GLES20.glBindTexture(
            GLES20.GL_TEXTURE_2D,
            textureId
        )

        GLES20.glTexParameteri(
            GLES20.GL_TEXTURE_2D,
            GLES20.GL_TEXTURE_MIN_FILTER,
            GLES20.GL_LINEAR
        )

        GLES20.glTexParameteri(
            GLES20.GL_TEXTURE_2D,
            GLES20.GL_TEXTURE_MAG_FILTER,
            GLES20.GL_LINEAR
        )

        GLUtils.texImage2D(
            GLES20.GL_TEXTURE_2D,
            0,
            bitmap,
            0
        )

        GLES20.glBindTexture(
            GLES20.GL_TEXTURE_2D,
            0
        )

        bitmap.recycle()

        return textureId
    }
}
